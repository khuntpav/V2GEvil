import asyncio
import socket


class ServerManager:
    """
    Class for managing the servers

    Class for managing the servers (SDP, TCP, TLS)
    """

    def __init__(self, interface: str = "eth_station"):
        """Initialize Server Manager."""
        self.interface = interface
        self.ipv6_address = "fe80::d237:45ff:fe88:b12b"  # Hardcoded for now
        self.udp_stop_flag = asyncio.Event()

    async def start(self):
        """Start station.

        To handle stop of SDP server after TCP connection is established,
        it's necessary to use threading (or maybe asyncio)."""

        # After Data-Link is established
        udp_task = asyncio.create_task(self.sdp_server())
        await udp_task

        # OR ???
        # udp_task = asyncio.create_task(self.sdp_server())
        # tcp_task = asyncio.create_task(self.tcp_server())
        # await asyncio.gather(udp_task, tcp_task)

    async def sdp_server(self):
        """Start SDP server.

        The SDP server is started on UDP (multicast) port 15118 (defined in ISO15118-2).
        Should accepts UDP packets with a local-link IP multicast destination address
        """
        print("SDP server started")

        # Create a UDP socket
        sdp_socket = socket.socket(
            family=socket.AF_INET6, type=socket.SOCK_DGRAM
        )
        # Get interface index
        interface_index = socket.if_nametoindex(self.interface)
        # Bind to the multicast group address
        port = V2G_UDP_SDP_SERVER

        multicast_address = "ff02::1"
        logger.debug(
            socket.getaddrinfo(
                multicast_address,
                port,
                socket.AF_INET6,
                socket.SOCK_DGRAM,
                socket.SOL_UDP,
            )
        )
        # Bind socket to multicast_address
        sdp_socket.bind((multicast_address, port, 0, interface_index))

        logger.debug(sdp_socket.getsockname())

        # Without this was not possible to listen on multicast
        multicast_addr_bin = socket.inet_pton(
            socket.AF_INET6, multicast_address
        )
        mreq = multicast_addr_bin + struct.pack("I", interface_index)
        sdp_socket.setsockopt(
            socket.IPPROTO_IPV6, socket.IPV6_JOIN_GROUP, mreq
        )

        logger.debug(
            "Starting SDP server, interface: %s interface-index: %s",
            self.interface,
            socket.if_nametoindex(self.interface),
        )

        try:
            while not self.udp_stop_flag.is_set():
                print("SDP server is running in while loop")
                data, addr = sdp_socket.recvfrom(1024)
                print(f"Received {len(data)} bytes from {addr}: {data}")

                response_message = b"SDP response from server"
                sdp_socket.sendto(response_message, addr)

                await self.tcp_server()
            print("SDP server stopped")
            sdp_socket.close()
        except KeyboardInterrupt:
            print("Stopping SDP server by KeyboardInterrupt")
            sdp_socket.close()

    async def tcp_server(self):
        """Run TCP server.

        Wait for connection from EVCC.
        After connection is established, stop the SDP server
        and wait for V2G communication session
        """
        print("TCP server started")
        with socket.socket(
            family=socket.AF_INET6, type=socket.SOCK_STREAM
        ) as server_sock:
            # Get interface index
            interface_index = socket.if_nametoindex(self.interface)
            # Bind to the multicast group address
            port = random.randint(
                V2G_DST_TCP_DATA.start, V2G_DST_TCP_DATA.stop
            )
            link_local_address = "fe80::d237:45ff:fe88:b12b"

            # Avoid bind() exception: OSError: [Errno 48] Address already in use
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(
                ("fe80::d237:45ff:fe88:b12b", 15119, 0, interface_index)
            )
            server_sock.listen()
            # This will accept only one client
            #  server doesn't accept new connections for each iteration of the loop
            # if i want that i should use while True and accept() in the loop

            conn, addr = server_sock.accept()
            with conn:
                print("Connected by: ", addr)
                self.udp_stop_flag.set()
                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    print(f"Received from: {addr} data: {data}")
                    # Send response
                    response_message = b"Hello from Server"
                    conn.sendall(response_message)
            # This is to run SDP server again after TCP connection is close
            self.udp_stop_flag.clear()


class ServerManager:
    # ... (other methods and __init__ are the same)

    async def start(self):
        udp_task = asyncio.create_task(self.sdp_server())
        await udp_task

    async def sdp_server(self):
        # ... (existing code)

        try:
            while not self.udp_stop_flag.is_set():
                print("SDP server is running in while loop")
                data, addr = sdp_socket.recvfrom(1024)
                print(f"Received {len(data)} bytes from {addr}: {data}")

                response_message = b"SDP response from server"
                sdp_socket.sendto(response_message, addr)

                if not self.tcp_continue_flag.is_set():
                    try:
                        # Wait for TCP server to connect within a timeout
                        await asyncio.wait_for(self.tcp_server(), timeout=10)
                    except asyncio.TimeoutError:
                        print("TCP server connection timeout")

        except KeyboardInterrupt:
            print("Stopping SDP server by KeyboardInterrupt")
        finally:
            print("SDP server stopped")
            sdp_socket.close()

    async def tcp_server(self):
        with socket.socket(
            family=socket.AF_INET6, type=socket.SOCK_STREAM
        ) as server_sock:
            # ... (existing code)

            server_sock.setblocking(False)
            try:
                while not self.tcp_continue_flag.is_set():
                    try:
                        conn, addr = server_sock.accept()
                        with conn:
                            print("Connected by: ", addr)
                            self.tcp_continue_flag.set()

                            while True:
                                data = conn.recv(1024)
                                if not data:
                                    break
                                print(f"Received from: {addr} data: {data}")
                                response_message = b"Hello from Server"
                                conn.sendall(response_message)
                    except BlockingIOError:
                        await asyncio.sleep(1)  # Non-blocking wait
            except KeyboardInterrupt:
                print("Stopping TCP server by KeyboardInterrupt")
