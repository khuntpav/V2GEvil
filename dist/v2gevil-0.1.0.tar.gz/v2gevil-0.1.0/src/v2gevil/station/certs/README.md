# User of this tool has to generate his own certificate and key

## certificate filename should be: evse_cert.pem
## key filename should be: evse_key.key