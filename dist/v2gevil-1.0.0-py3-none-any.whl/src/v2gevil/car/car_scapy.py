"""Module for car implementation.

This implementation will be done by using Scapy library."""
