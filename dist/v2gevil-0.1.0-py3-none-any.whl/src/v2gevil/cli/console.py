"""Console object for rich"""
from rich.console import Console

console = Console()
