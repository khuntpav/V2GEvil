import asyncio


class ServerManager:
    def __init__(self):
        self.udp_stop_flag = asyncio.Event()

    async def start(self):
        """Start station."""
        udp_task = asyncio.create_task(self.sdp_server())
        tcp_task = asyncio.create_task(self.tcp_server())

        # Wait for both tasks to complete
        await asyncio.gather(udp_task, tcp_task)
        # await udp_task
        # await tcp_task

    async def sdp_server(self):
        """Start SDP server."""
        print("SDP server started")
        while not self.udp_stop_flag.is_set():
            print("SDP server is running...")
            await asyncio.sleep(0.1)  # Optional: Yield control to event loop
        print("SDP server stopped")

    async def tcp_server(self):
        """Run TCP server."""
        print("TCP server started")

        await asyncio.sleep(1)  # Simulate waiting for a connection

        while True:
            print("TCP server is running...")
            await asyncio.sleep(0.1)

        # After some time, set the flag to stop SDP server
        await asyncio.sleep(3)
        self.udp_stop_flag.set()

        print("TCP server finished")


if __name__ == "__main__":
    server = ServerManager()
    asyncio.run(server.start())
